<?php
namespace App\Models;
use CodeIgniter\Model;
use App\Entities\laptop;

class LaptopModel extends Model{
    protected $table = 'laptop';
    protected $primarykey = 'id';
    protected $returnType= Laptop::class;
    protected$allowedFields =['marca','modelo','color','descripcion']; 
    public function getLaptop(){
        return $this->findAll();
    }
    
}
?>