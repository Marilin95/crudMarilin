<!DOCTYPE html>
<html>

<head>
  <title>Crear registro de laptop</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<style>
    .container {
      max-width: 500px;
    }
    .error {
      display: block;
      padding-top: 5px;
      font-size: 14px;
      color: red;
    }
  </style>
</head>

<body>
  <div class="container mt-5">
  <h1>Registro de laptop</h1>
    <form method="post" id="crear" name="crear" 
    action="<?= site_url('/crearlaptop') ?>">
      <div class="form-group">
        <label>Marca</label>
        <input type="text" name="marca" class="form-control">
      </div>

      <div class="form-group">
        <label>Modelo</label>
        <input type="text" name="modelo" class="form-control">
      </div>

      <div class="form-group">
        <label>Color</label>
        <input type="text" name="color" class="form-control">
      </div>

      <div class="form-group">
        <label>Descripcion</label>
        <input type="text" name="descripcion" class="form-control">
      </div>

      <div class="form-group">
        <button type="submit" class="btn btn-success">Agregar</button>
      </div>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"></script>
  <script>
    if ($("#add_crear").length > 0) {
      $("#add_crear").validate({
        rules: {
          marca: {
            required: true,
          },
          modelo:{
              required:true,
          },
          color:{
              require: true,
          },
          decripcion: {
              require:true,
          },
        },
        messages: {
          marca: {
            required: "required.",
          },
          modelo: {
            required: "required.",
          },
          color: {
            required: "required.",
          },
          descripcion: {
            required: "required.",
          },
        },
      })
    }
  </script>
</body>

</html>