<!DOCTYPE html>
<html>

<head>
  <title>Editar</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
   <style> .container {
      max-width: 500px;
    }

    .error {
      display: block;
      padding-top: 5px;
      font-size: 14px;
      color: red;
    }
  </style>
</head>

<body>
  <div class="container mt-5">

  <h1>Editar Registro</h1>

    <form method="post" id="editar" name="editar" 
    action="<?= site_url('/editar') ?>">
      <input type="hidden" name="id" id="id" value="<?php echo $laptop_obj->id; ?>">

      <div class="form-group">
        <label>Marca</label>
        <input type="text" name="marca" class="form-control" value="<?php echo $laptop_obj->marca; ?>">
      </div>

      <div class="form-group">
        <label>Modelo</label>
        <input type="text" name="modelo" class="form-control" value="<?php echo $laptop_obj->modelo; ?>">
      </div>

      <div class="form-group">
        <label>Color</label>
        <input type="text" name="color" class="form-control" value="<?php echo $laptop_obj->color; ?>">
      </div>

      <div class="form-group">
        <label>descripcion</label>
        <input type="text" name="descripcion" class="form-control" value="<?php echo $laptop_obj->descripcion; ?>">
      </div>

      <div class="form-group">
        <button type="submit" class="btn btn-warning">Editar</button>
      </div>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"></script>
  <script>
    if ($("#editar").length > 0) {
      $("#editar").validate({
        rules: {
          marca: {
            required: true,
          },
          modelo: {
              require: true,
          },
          color: {
              require: true,
          },
          descripcion: {
              require: true,
          },
         
        },
        messages: {
          marca: {
            required: "required.",
          },
          modelo: {
            required: "required.",
          },
          color: {
            required: "required.",
          },
          descripcion: {
            required: "required.",
          },
        },
      })
    }
  </script>
</body>

</html>