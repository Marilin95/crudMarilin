<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Crud de Laptops</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <div class="container mt-4">
        <h1>laptops</h1>

        <div class="d-flex justify-content-end">
            <a href="<?php echo site_url('/crear') ?>" class="btn btn-primary">Agregar</a>
        </div>
        <?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?>
        <div class="mt-3">
            <table class="table table-bordered" id="users-list">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Color</th>
                        <th>Descripcion</th>

                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($laptop): ?>
                    <?php foreach($laptop as $laptop): ?>
                    <tr>
                        <td><?php echo $laptop->id; ?></td>
                        <td><?php echo $laptop->marca?></td>
                        <td><?php echo $laptop->modelo?></td>
                        <td><?php echo $laptop->color?></td>
                        <td><?php echo $laptop->descripcion?></td>
                        <td>
                            <a href="<?php echo base_url('editar/'.$laptop->id);?>" class="btn btn-primary">Editar</a>
                            <a href="<?php echo base_url('delete/'.$laptop->id);?>" class="btn btn-danger">Eliminar</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    
    </script>
    </body>

</html>