<?php
namespace App\Controllers;
use App\Models\LaptopModel;

class Laptop extends BaseController{
    public function ver(){
        $modelolaptop = model(laptopModel::class);
        $data['laptop'] = $modelolaptop->getLaptop();
        
        return view('laptop/ver',$data);
       
    }
    public function crear(){
        return view('laptop/crear');
    }
    public function accionescrear(){
        $modelolaptop = model(LaptopModel::class);
        $data = [
            'marca' =>$this->request->getVar('marca'),
            'modelo' =>$this->request->getVar('modelo'),
            'color' =>$this->request->getVar('color'),
            'descripcion' =>$this->request->getVar('descripcion'),
        ];
        $modelolaptop->insert($data);
        return $this->response->redirect(site_url('/ver'));
    }
    public function editar($id = null){
        $modelolaptop = model(LaptopModel::class);
        $data['laptop_obj']= $modelolaptop->where('id',$id)->first();
        return view('laptop/editar', $data);
    }
    public function accioneseditar(){
        $modelolaptop = model(LaptopModel::class);
        $id =$this->request->getVar('id');
        $data = [
            'marca' =>$this->request->getVar('marca'),
            'modelo' =>$this->request->getVar('modelo'),
            'color' =>$this->request->getVar('color'),
            'descripcion' =>$this->request->getVar('descripcion'),
        ];
        $modelolaptop->update($id, $data);
        return $this->response->redirect(site_url('/ver'));
    }
    /*public function eliminar($id = null){
        $modelolaptop = model(LaptopModel::class);
        $data['eliminar_user'] = $modelolaptop->where('id', $id)->eliminar($id);
        return $this->response->redirect(site_url('/ver'));
    }*/
    public function delete($id = null){
        $model = model(LaptopModel::class);
        $data['delete_user'] = $model->where('id', $id)->delete($id);
        return $this->response->redirect(site_url('/ver'));
    }
}
?>